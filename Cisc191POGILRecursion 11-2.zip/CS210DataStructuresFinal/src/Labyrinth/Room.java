package Labyrinth;

import java.util.*;

public class Room {
    String name;
    String description;
    Map<String, Room> connections; // adjacency list
//    List<String> items;
    Monster monster;
    DecisionTree decisionTree; // Add decision tree to the room

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
        this.connections = new HashMap<>();
//        this.items = new ArrayList<>();
    }

    public void connectRoom(String direction, Room room) {
        connections.put(direction.toLowerCase(), room);
    }

    public Room getConnectedRoom(String direction) {
        return this.connections.get(direction);
    }
    
//    public void addItem(String item) {
//        items.add(item);
//    }

//    public void removeItem(String item) {
//        items.remove(item);
//    }

    public boolean hasMonster() {
        return monster != null;
    }

    public void setMonster(Monster monster) {
        this.monster = monster;
    }

    public void setDecisionTree(DecisionTree tree) {
        this.decisionTree = tree;
    }

    public boolean hasDecisionTree() {
        return decisionTree != null;
    }

    // void setTrap(int i) {
    //     System.out.println("Oh no! You triggered a trap and lost " + trapDamage + " health!");
    //     player.reduceHealth(currentRoom.trapDamage);
    //     currentRoom.clearTrap(); // Trap is one-time use    }

 
    
}
