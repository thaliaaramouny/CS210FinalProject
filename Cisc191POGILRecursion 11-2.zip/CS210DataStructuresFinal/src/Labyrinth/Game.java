package Labyrinth;

import java.util.*;

public class Game {
	//prevent the player from reentering visited rooms
	static Set<Room> visitedRooms = new HashSet<>();

    // Player setup
    static Player player = new Player();
    
    private static void displayCountdown(long timeLimit) {
        long startTime = System.currentTimeMillis();
        long elapsedTime = 0;
        System.out.print("Time left: ");
        // Countdown loop
        while (elapsedTime < timeLimit) {
            elapsedTime = System.currentTimeMillis() - startTime;
            long remainingTime = (timeLimit - elapsedTime) / 1000; // Convert to seconds
            System.out.print( remainingTime + " |");
            try {
                Thread.sleep(1000); // Wait for 1 second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    //thread
    private static void createRiddleWithCountdown(Player player, Scanner scanner) {
        // Riddle setup
        DecisionTree riddleTree = createRiddleTree();
        CountdownThread countdownThread = new CountdownThread(30000); // 30 seconds countdown

        // Start the countdown thread
        countdownThread.start();

        // Allow the player to answer the riddle
        traverseDecisionTree(riddleTree, player, scanner);
        countdownThread.interrupt();  // Stop the timer immediately after the player answers

        // Wait for the countdown thread to finish (or stop it early if needed)
        try {
            countdownThread.join();  // Wait for countdown to complete
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Handle end of countdown or decision tree completion
        if (countdownThread.isTimeExpired()) {
            System.out.println("You failed to solve the riddle in time. The orb is locked forever!");
        } else {
            System.out.println("You solved the riddle!");
        }
    }


    //room1    
    private static DecisionTree enterRoom1() {
        DecisionTree root = new DecisionTree("You step into the room and hear a click. \n" + "A trap is triggered! What will you do?");
        
        System.out.println("Choices \n" + 
        "a. Carefully, escape the trap! Why would I want to hurt myself?! \n" +
        "b. Give in to the pain. I might gain xp from this." );

        // If the player decides to dodge or disarm the trap
        DecisionTree escape = new DecisionTree("You avoid the trap and carefully step aside.", "You safely avoid the trap!");
        
        // If the player chooses to trigger the trap
        DecisionTree trigger = new DecisionTree("Are you sure you want to go through the pain?", "Your health deacreases by 50HP.");
        trigger.addChoice("Yes", new DecisionTree("You lose a lot of blood.", "Unfortunately, the trap does not give you xp. Your sacrifice was useless.") {
         @Override
         public void applyStatsChange(Player player) {
             player.reduceHealth(50); //the player takes 50 damage for thinking trap will give xp
	         	}
	        });  

		 root.addChoice("a", escape);
		 root.addChoice("b", trigger);
		 
		
		 return root;
		}
//room 2
private static DecisionTree createItemInteractionTree() {
			 //root
		 DecisionTree root = new DecisionTree("You find a Healing Potion and a Shield in this room. What will you do?");
		 
		 System.out.println("Choices: \n" + 
					 "a. Pick up shield and healing potion. I'll use them later \n" 
					 + "b. Leave, these items will slow me down \n" 
					 + "c. Use the potion right now, I might not get the chance later");
		 //player picks up the healing potion and shield
		 DecisionTree pickItems = new DecisionTree("You pick up the Healing Potion and Shield.", 
		         "You now have a Healing Potion and Shield. They will be useful in Room 3 when facing the monster!");
		 pickItems.addChoice("Continue", new DecisionTree("Items added to inventory.", "You can use them from your inventory later.") {
	         @Override
	         public void updateInventory(Player player) {
	             player.addItem("Shield");
		         	}
		        });  
		
		 //if the player chooses to leave the items behind
		 DecisionTree leaveItems = new DecisionTree("You decide not to pick up the items because you are tired (or lazy).", 
		         "You leave the Healing Potion and Shield behind. You might regret this decision later...");
		
		 //if player takes potion
		 DecisionTree heal = new DecisionTree("Do you feel renewed?", "You restore health!");
		 heal.addChoice("yes", new DecisionTree ("You use the Healing Potion to heal yourself.") {
	         @Override
	         public void applyStatsChange(Player player) {
	             player.increaseHealth(20); //the player takes 20hp
		         	}
		 });
		
		 root.addChoice("a", pickItems);
		 root.addChoice("b", leaveItems);
		 root.addChoice("c", heal);
		
		 return root;
		}


//room 3
private static DecisionTree createCombatTree() {
	System.out.print("Choices: \n" + 
	"a. Attack!!!" +
				"b. ");
	 DecisionTree root = new DecisionTree("A monster attacks! You spill your healing potion. What will you do?");
	 //if the player has the shield and chooses to use it
	 DecisionTree shield = new DecisionTree("You use the Shield to defend yourself.", "The shield reduces the damage taken!");
	 DecisionTree attack = new DecisionTree("You attack the monster.", "You dealt damage and defeated the monster!");
	 // Apply damage here when attacking the monster
	 attack.addChoice("continue", new DecisionTree("The monster attacks back!", "You take 5 damage.") {
	     @Override
	     public void applyStatsChange(Player player) {
	         player.reduceHealth(5); // The player takes 5 damage if the monster attacks back
	     }
	 });    
	 DecisionTree defend = new DecisionTree("You defend yourself.", "You blocked the attack but took minor damage.");
	 DecisionTree flee = new DecisionTree("You flee from the monster.", "You escaped safely, but the monster is still there.");
	
	 root.addChoice("attack", attack);
	 root.addChoice("shield", shield);
	 root.addChoice("defend", defend);
	 root.addChoice("flee", flee);
	
	 return root;
	}

//room 4
private static DecisionTree createRiddleTree() {
	DecisionTree root = new DecisionTree("A riddle appears before you: 'What comes once in a minute, twice in a moment, but never in a thousand years? What is it?'");
	 
	// If the player answers correctly
	DecisionTree correctAnswer = new DecisionTree("You answered correctly! You receive the Orb of Justice!", "The Orb of Justice is in safe hands. You saved your kingdom. Congratulations, YOU WIN! ");
	 
	// If the player answers incorrectly
	DecisionTree incorrectAnswer = new DecisionTree("Wrong answer.", "The room starts to collapse. You lose!");
	 
	root.addChoice("time", correctAnswer);  // Correct answer is 'time'
	root.addChoice("other", incorrectAnswer);  // Incorrect answer
	 
	return root;
	}



private static void traverseDecisionTree(DecisionTree node, Player player, Scanner scanner) {
	 while (!node.isLeaf()) {
	     System.out.println(node.question);  // Display the current decision point's question to the player
	     System.out.println("Choices: " + node.choices.keySet());  // Display available choices to the player
	     
	     String choice = scanner.nextLine().toLowerCase();  // Get the player's choice as input, converted to lowercase
	
	     if (node.choices.containsKey(choice)) {
	         node = node.choices.get(choice);  // Move to the next node based on the player's choice
	         node.applyStatsChange(player);  // Apply any changes to the player's stats if needed (e.g., health or attack)
	     } else {
	         System.out.println("Invalid choice. Try again.");  // Inform the player if the choice is invalid
	     }
	 }
	
	 System.out.println(node.result);  // Once a leaf node is reached (no further choices), print the result
	}


// Map visualization
private static void printMap() {
	 System.out.println("\n=== Labyrinth Map ===");
	 System.out.println("     [Room 4]");
	 System.out.println("       ^");
	 System.out.println("     [Room 3]");
	 System.out.println("       ^");
	 System.out.println("     [Room 2]");
	 System.out.println("       ^");
	 System.out.println("     [Room 1]");
	 System.out.println("       ^");
	 System.out.println("     [Start]");
	 System.out.println("=====================");
	}

public static void main(String[] args) {

 // Initialize rooms and player
 Room start = new Room("Start", "You are at the labyrinth entrance.");
 Room room1 = new Room("Room 1", "You are in room 1");
 Room room2 = new Room("Room 2", "You find a Healing Potion and a Shield here.");
 Room room3 = new Room("Room 3", "A monster appears!");
 Room room4 = new Room("Room 4", "Solve the riddle to win the Orb of Justice.");
 
 // Connect rooms
 start.connectRoom("north", room1);
 room1.connectRoom("south", start);
 room1.connectRoom("east", room2);
 room2.connectRoom("west", room1);
 room2.connectRoom("north", room3);
 room3.connectRoom("south", room2);
 room3.connectRoom("east", room4);
 room4.connectRoom("west", room3);


    // Room contents
    //room1.setTrap(5); // Trap reduces health by 5
//    room2.addItem("Healing Potion");
//    room2.addItem("Shield");
 //   room3.setMonster(new Monster("Ogre", 10, 8));
    //room4.setRiddle("What comes once in a minute, twice in a moment, but never in a thousand years?", "time");

    // Display map
    printMap();     

    // Gameplay loop
    Room currentRoom = start;
    Stack<Room> roomHistory = new Stack<>();
    Scanner scanner = new Scanner(System.in);

    while (true) {
        // Display current room and its details
        System.out.println("\n" + currentRoom.name + ": " + currentRoom.description);

        /*  Check room for traps
        if (currentRoom.hasTrap()) {
            System.out.println("Oh no! You triggered a trap and lost " + currentRoom.trapDamage + " health!");
            player.reduceHealth(currentRoom.trapDamage);
            currentRoom.clearTrap(); // Trap is one-time use
            if (player.getHealth() <= 0) {
                System.out.println("You have succumbed to your injuries. Game over!");
                break;
            }
        }
        */

//        // Check room items
//        if (!currentRoom.items.isEmpty()) {
//            System.out.println("You see the following items: " + currentRoom.items);
//        }
        
        // Combat in room 3
        if (currentRoom.hasMonster()) {
            System.out.println("A " + currentRoom.monster.name + " is here!");
            traverseDecisionTree(createCombatTree(), player, scanner);
            currentRoom.monster = null; // Remove the monster after combat
        }

        // Room-specific logic
        if (currentRoom == room1) {
           	System.out.println("The room is dark, you might hurt yourself walking in there but the ord might be there!" +
           	        "Do you want to walk in? yes/no");
            String input = scanner.nextLine(); // Get player input

	    	if (input == "yes") {        	
	        traverseDecisionTree(enterRoom1(), player, scanner);
	        } 
	    	else if (input == "no"){
	    		System.out.println("The doors shut behind you. You hear a loud voice 'There is no escape of this labyrinth without the orb.' \n" + 
	    	"The voice scares you and you tumble into room 2."); 
	    		currentRoom = room2;
	    	}
        } else if (currentRoom == room2) {
            traverseDecisionTree(createItemInteractionTree(), player, scanner); // Item interaction
        } else if (currentRoom == room4) {
            System.out.println("Solve this riddle to claim the Orb of Justice!");
            createRiddleWithCountdown(player, scanner); 
            break;//riddle tree with countdown timer
        }

        
        // Movement and actions
        System.out.println("Available directions: " + currentRoom.connections.keySet());
        System.out.print("Type a direction, 'inventory', 'stats', 'use [item]', 'undo', or 'quit': ");
        String input = scanner.nextLine().toLowerCase();

        if (input.equals("quit")) {
            System.out.println("Thanks for playing!");
            break;
        } 
//        else if (input.startsWith("pick ")) {
//            String item = input.substring(5);
//            if (currentRoom.items.contains(item)) {
//                player.addItem(item);
//                currentRoom.removeItem(item);
//                System.out.println("You picked up: " + item);
//            } else {
//                System.out.println("Item not found in this room.");
//            }
//        }
         else if (input.equals("inventory")) {
            player.viewInventory();
        } else if (input.startsWith("use ")) {
            String item = input.substring(4);
         //    if (player.useItem(item)) {
         //        System.out.println("You used: " + item);
         //    } else {
         //        System.out.println("You don't have this item.");
         //    }
        } else if(input.equals("stats")){
         System.out.println(player.stats);
         } 
        else if (input.equals("undo")) {
            if (!roomHistory.isEmpty()) {
                currentRoom = roomHistory.pop(); // Go back to the previous room
            }
        } else if (input.equals("north") || input.equals("south") || input.equals("east") || input.equals("west")) {
            Room nextRoom = currentRoom.getConnectedRoom(input); // Get the room in the chosen direction
            if (nextRoom != null) {
                // Unrestricted access to Start
                if (nextRoom.name.equals("Start")) {
                    System.out.println("You head " + input + " to " + nextRoom.name + ".");
                    roomHistory.push(currentRoom);
                    currentRoom = nextRoom;
                } 
                // Check if the room was visited before
                else if (visitedRooms.contains(nextRoom)) {
                    System.out.println("You have already visited this room. Do you want to go there anyway? (yes/no)");
                    String choice = scanner.nextLine().trim().toLowerCase();
                    if (choice.equals("yes")) {
                        System.out.println("You head " + input + " to " + nextRoom.name + ".");
                        roomHistory.push(currentRoom);
                        currentRoom = nextRoom;
                    } else {
                        System.out.println("You decide to stay in the current room.");
                    }
                } 
                // First-time visit to the room
                else {
                    System.out.println("You head " + input + " to " + nextRoom.name + ".");
                    roomHistory.push(currentRoom);
                    currentRoom = nextRoom;
                    visitedRooms.add(currentRoom); // Mark room as visited
                }
            } else {
                System.out.println("There is no path in that direction.");
            }
        } else {
            System.out.println("Invalid direction.");
        }



    }
    
    scanner.close();
}
}


