package Labyrinth;

import java.util.*;

public class Player {
    private List<String> inventory; // Player's inventory
    Map<String, Integer> stats; // Player's stats (health, XP)

    // Constructor
    public Player() {
        inventory = new ArrayList<>();
        stats = new HashMap<>();
        stats.put("health", 100); // Starting health
        stats.put("XP", 0);       // Starting XP
    }

    // Set player's health, ensuring it doesn't go below 0
    private void setHealth(int health) {
        stats.put("health", Math.max(health, 0)); // Prevent negative health
    }

    // Get player's current health
    private int getHealth() {
        return stats.get("health");
    }

    // Increase player's health by a specified amount
    public void increaseHealth(int heal) {
        int newHealth = getHealth() + heal;
        setHealth(newHealth);
        System.out.println("You take " + heal + " healing points. Current health: " + getHealth());

        if (getHealth() <= 0) {
            System.out.println("GAME OVER. You died.");
        }
    }

    // Reduce player's health by a specified amount
    public void reduceHealth(int damage) {
        int newHealth = getHealth() - damage;
        setHealth(newHealth);
        System.out.println("You take " + damage + " damage. Current health: " + getHealth());

        if (getHealth() <= 0) {
            System.out.println("You have been defeated.");
        }
    }

    // Add item to the inventory
    public void addItem(String item) {
        inventory.add(item);
        System.out.println(item + " has been added to your inventory.");
    }

    // Remove item from the inventory
    public void removeItem(String item) {
        inventory.remove(item);
        System.out.println(item + " has been removed from your inventory.");
    }

    // View all items in the inventory
    public void viewInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Your inventory is empty.");
        } else {
            System.out.println("Your inventory: " + inventory);
        }
    }

    // Use an item from the inventory
    public boolean useItem(String item) {
        if (inventory.contains(item)) {
            switch (item.toLowerCase()) {
                case "healing potion":
                    System.out.println("You use the Healing Potion and recover 20 health.");
                    increaseHealth(20); // Increase health by 20
                    break;
                case "key":
                    System.out.println("You use the Key to unlock a mysterious door.");
                    break;
                default:
                    System.out.println("You can't use " + item + " right now.");
                    break;
            }
            inventory.remove(item); // Remove the used item from inventory
            return true;
        } else {
            System.out.println("Item not found in your inventory.");
            return false;
        }
    }

    // Update player stats (health, XP, etc.)
    public void updateStats(int healthChange, int XPChange) {
        stats.put("health", stats.get("health") + healthChange);
        stats.put("XP", stats.get("XP") + XPChange);
        System.out.println("Stats updated: " + stats);
    }

    // Get player's current stats (health, XP, inventory)
    public String getStats() {
        return "Health: " + getHealth() + "\nXP: " + stats.get("XP") + "\nInventory: " + String.join(", ", inventory);
    }
}
