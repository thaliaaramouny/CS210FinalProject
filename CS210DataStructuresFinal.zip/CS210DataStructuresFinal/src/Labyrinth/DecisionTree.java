package Labyrinth;

import java.util.*;

public class DecisionTree {
    String question; // The question or decision prompt
    Map<String, DecisionTree> choices; //choices available at this node
    String result; //outcome if this is a leaf node
    boolean affectsPlayerStats;  //if this decision affects the player's stats
    int healthChange;
    int XPChange;
    String item;

    // Constructor for intermediate nodes
    public DecisionTree(String question) {
        this.question = question;
        this.choices = new HashMap<>();
    }

    // Constructor for leaf nodes
    public DecisionTree(String question, String result) {
        this.question = question;
        this.choices = new HashMap<>();
        this.result = result;
        this.affectsPlayerStats = false;  // Default to no stat change
    }
    
    public void updateInventory(Player player) {
		//player.addItem(item);
    }

public void applyStatsChange(Player player) {
    if (affectsPlayerStats) {
        player.updateStats(healthChange, XPChange); 
    }
}

public boolean canChoose(Player player) {
    if (item != null && !item.isEmpty() && !player.hasItem(item)) {
        return false; // Return false if the player doesn't have the required item
    }
    return true;  // Allow action if the item is available
}


    // Add a choice leading to another node
    public void addChoice(String choice, DecisionTree nextNode) {
        choices.put(choice.toLowerCase(), nextNode);
    }

    // Check if this node is a leaf
    public boolean isLeaf() {
        return choices.isEmpty();
    }
}
