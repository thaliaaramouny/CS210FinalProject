package Labyrinth;

import java.util.*;

public class Player {
    List<String> inventory; // player's inventory
    Map<String, Integer> stats; // player's stats (health, XP, level)
    int capacity = 10; // max inventory size

    // Constructor
    public Player() {
        inventory = new ArrayList<>();
        stats = new HashMap<>();
        stats.put("health", 70); // Starting health
        stats.put("XP", 0);       // Starting XP
        stats.put("level", 1);    // Starting level
    }

    // Set player's health, ensuring it doesn't go below 0
    private void setHealth(int health) {
        stats.put("health", Math.max(health, 0)); // Prevent negative health
        if (stats.get("health") == 0) {
            System.out.println("GAME OVER. You died.");
        }
    }

    // Get player's current health
    public int getHealth() {
        return stats.get("health");
    }
    
    // Method to check if the player is dead
    public boolean isDead() {
        return stats.get("health") <= 0;  // Check health from stats map
    }

    // Increase player's health
    public void increaseHealth(int heal) {
        int newHealth = getHealth() + heal;
        setHealth(newHealth);
        System.out.println("You take " + heal + " healing points. Current health: " + getHealth());
    }

    // Reduce player's health
    public void reduceHealth(int damage) {
        int newHealth = getHealth() - damage;
        setHealth(newHealth);
        System.out.println("You take " + damage + " damage. Current health: " + getHealth());
    }

    // Add item to the inventory
    public void addItem(String item) {
        if (inventory.size() < capacity) {
            inventory.add(item);
            System.out.println(item + " has been added to your inventory.");
        } else {
            System.out.println("Your inventory is full!");
        }
    }

    // Remove item from the inventory
    public void removeItem(String item) {
        if (inventory.remove(item)) {
            System.out.println(item + " has been removed from your inventory.");
        } else {
            System.out.println(item + " is not in your inventory.");
        }
    }

    // View all items in the inventory
    public void viewInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Your inventory is empty.");
        } else {
            System.out.println("Your inventory: " + inventory);
        }
    }

    // Use an item from the inventory
    public void useItem(String item) {
        if (inventory.contains(item)) {
            switch (item.toLowerCase()) {
                case "healing potion":
                    System.out.println("You use the Healing Potion and recover 20 health.");
                    increaseHealth(20);
                    break;
                case "key":
                    System.out.println("You use the Key to unlock a mysterious door.");
                    break;
                default:
                    System.out.println("You can't use " + item + " right now.");
            }
            inventory.remove(item); // Remove the used item from inventory
        } else {
            System.out.println("Item not found in your inventory.");
        }
    }

    //check if player levels up based on XP
    public void checkLevelUp() {
        int XP = stats.get("XP");
        int currentLevel = stats.get("level");
        int XPThreshold = currentLevel * 10; //XP needed to level up

        if (XP >= XPThreshold) {
            stats.put("level", currentLevel + 1); //increase level
            stats.put("health", getHealth() + 20); //reward health increase
            stats.put("XP", XP - XPThreshold); //deduct XP threshold
            System.out.println("Congratulations! You've leveled up to level " + stats.get("level") + "!");
        }
    }

    //check if player has a specific item
    public boolean hasItem(String item) {
        return inventory.contains(item);
    }

    // Add experience points to the player
    public void addExperience(int XPChange) {
        stats.put("XP", stats.get("XP") + XPChange);
        System.out.println("You gained " + XPChange + " XP!");
        checkLevelUp(); // Check for level-up after gaining XP
    }

    // Update player stats
    public void updateStats(int healthChange, int XPChange) {
        setHealth(getHealth() + healthChange);
        stats.put("XP", stats.get("XP") + XPChange);
        checkLevelUp(); // Check for level-up
        System.out.println("Stats updated: " + getStats());
    }

    // Get player's current stats
    public String getStats() {
        return "Health: " + getHealth() + "\nXP: " + stats.get("XP") + "\nLevel: " + stats.get("level") +
                "\nInventory: " + (inventory.isEmpty() ? "Empty" : String.join(", ", inventory));
    }
    
    public void resetStats() {
        stats.put("health", 70); // Reset to starting health
        stats.put("XP", 0);      // Reset XP
        stats.put("level", 1);   // Reset level
        inventory.clear();       // Clear inventory
    }


}
