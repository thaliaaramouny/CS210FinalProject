package Labyrinth;

import java.util.*;

public class Game {
	//prevent the player from reentering visited rooms
	static Set<Room> visitedRooms = new HashSet<>();

    //creating player 
    static Player player = new Player();
    

    //thread
    private static void createRiddleWithCountdown(Player player, Scanner scanner) {
        // Riddle setup
        DecisionTree riddleTree = createRiddleTree();
        CountdownThread countdownThread = new CountdownThread(30000); // 30 seconds countdown

        // Start the countdown thread
        countdownThread.start();

        // Prompt player for riddle answer
        System.out.println(riddleTree.question);

        String answer = scanner.nextLine().toLowerCase(); // Player inputs answer
        countdownThread.interrupt(); // Stop the timer as soon as the player answers

        try {
            countdownThread.join(); // Wait for thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Process riddle answer
        if (countdownThread.isTimeExpired()) {
            System.out.println("You failed to solve the riddle in time. The orb is locked forever!");
        } else if (answer.equals("m")) { // Correct answer
            riddleTree = riddleTree.choices.get("m");
            riddleTree.applyStatsChange(player);
            System.out.println(riddleTree.result);
        } else { // Incorrect answer
            riddleTree = riddleTree.choices.get("other");
            riddleTree.applyStatsChange(player);
            System.out.println(riddleTree.result);
        }
    }



    //room1    
    private static DecisionTree enterRoom1() {
        DecisionTree root = new DecisionTree("You step into the room and hear a click. \n" + "A trap is triggered! What will you do?" + "\n" 
        		+ "a. Carefully, escape the trap! Why would I want to hurt myself?! \n" 
        		+ "b. Give in to the pain. I might gain xp from this. Nothing is guaranteed. ");
        
        //avoid path
        DecisionTree escape = new DecisionTree("You disarm the trap and carefully step aside. \n" + "It looks like you gained xp from this!", "You safely avoid the trap!");
        DecisionTree gainXP = new DecisionTree("XP change. Check your stats", "Keep it up! You automatically level up when you reach 10XP.") {
	        @Override
	        public void applyStatsChange(Player player) {
	            player.addExperience(3); 
	        }
        };
        escape.addChoice("View XP", gainXP);
        
        //painful path
        DecisionTree trigger = new DecisionTree("Remember, you signed up for this...", "Your health deacreases by 50HP.");
        trigger.addChoice("ok", new DecisionTree("You lose a lot of blood.", "Unfortunately, the trap does not give you xp. Your sacrifice was useless.") {
         @Override
         public void applyStatsChange(Player player) {
             player.reduceHealth(50); //the player takes 50 damage for thinking trap will give xp
	         	}
	        }); 
               
		 root.addChoice("a", escape);
		 root.addChoice("b", trigger);
		 
		 return root;
		}
//room 2
private static DecisionTree createItemInteractionTree() {
			 //root
		 DecisionTree root = new DecisionTree("You find a Healing Potion and a Sword in this room. What will you do? \n" + "Choices: \n" + 
					 "a. Pick up sword and healing potion. I'll use them later \n" 
					 + "b. Leave, these items will slow me down \n" 
					 + "c. Leave the sword, but use the potion right now. I might not get the chance later");
		 
		 //player picks up the healing potion and sword
		 DecisionTree pickItems = new DecisionTree("You pick up the Healing Potion and Sword.", 
		         "You now have a Healing Potion and Sword. They will be useful in Room 3 when facing the monster!");
		 pickItems.addChoice("ok", new DecisionTree("Items added to inventory.", "You can use them from your inventory in the next room.") {
	         @Override
	         public void updateInventory(Player player) {
			        if (!player.hasItem("Sword")) {
			            player.addItem("Sword");
			        }
			        if (!player.hasItem("Healing Potion")) {
			            player.addItem("Healing Potion");
			        }
		            if (player.getHealth() < 70) {
		                player.reduceHealth(10);
		                System.out.println("You are already injured. You lost blood carrying those items!");
		            }
	         }
		 }); 
		
		 //player chooses to leave the items behind
		 DecisionTree leaveItems = new DecisionTree("You decide not to pick up the items because you are lazy.", 
		         "You leave the Healing Potion and Sword behind. You might regret this decision later...");
		
		 //player takes potion
		 DecisionTree heal = new DecisionTree("Do you feel renewed?", "You restored your health!") {
			    @Override
			    public void updateInventory(Player player) {
			        if (!player.hasItem("Healing Potion")) {
			            player.addItem("Healing Potion");
			        }
			    }
		        @Override
		        public void applyStatsChange(Player player) {
		            player.increaseHealth(70); // Damage from the monster
		        }
			};
		
		 root.addChoice("a", pickItems);
		 root.addChoice("b", leaveItems);
		 root.addChoice("c", heal);
		
		 return root;
		}


//room 3
private static DecisionTree createCombatTree() {
    DecisionTree root = new DecisionTree(
            "Your footsteps wake the Goblin up. He gets up angrily! What will you do? \n" +
            "Choices: \n" +
            "a. Attack! I'll swing at him with my fists.\n" +
            "b. Flee! I have no chance against him.\n" +
            "c. Use the sword! I can finish him. ") {
        @Override
        public void updateInventory(Player player) {
            //remove Healing Potion after spilled
            if (player.hasItem("Healing Potion")) {
                System.out.println("You spilled your Healing Potion!");
                player.removeItem("Healing Potion");
            }
        }
    };
    DecisionTree sword = new DecisionTree("You use the sword to attack.", "You slayed the Goblin!") {
    	@Override
    	public boolean canChoose(Player player) {
    	    if (!player.hasItem("Sword")) {
    	        System.out.println("You don't have a sword! The Goblin takes advantage of your hesitation and attacks.");
    	        player.reduceHealth(20); //penalty
    	        return false;
    	    }else {    	    return true;}
    	}

        @Override
        public void updateInventory(Player player) {
            player.removeItem("Sword");
        }

        @Override
        public void applyStatsChange(Player player) {
            player.addExperience(10); // Reward for defeating the Goblin
        }
    };
    // Attack path (using fists)
    DecisionTree attack = new DecisionTree("You attack the monster.", "You dealt damage, but the monster fled!") {
        @Override
        public void applyStatsChange(Player player) {
            player.reduceHealth(10); // Damage from the monster
            player.addExperience(5); // Reward for using fists
        }

        @Override
        public void updateInventory(Player player) {
            // Spilled potion in combat
            player.removeItem("Healing Potion");
        }
    };

    // Flee path
    DecisionTree flee = new DecisionTree("You try to flee, but the Goblin catches up!", "As you flee, the Goblin harmed you.") {
    	
        @Override
        public void applyStatsChange(Player player) {
            player.reduceHealth(20); // Fleeing could cause a penalty for failing to escape
            player.addExperience(2); // Small reward for fleeing

        }
        
    };

    // Link decisions
    root.addChoice("a", attack);
    root.addChoice("b", flee);
    root.addChoice("c", sword);


    return root;
}




//room 4
private static DecisionTree createRiddleTree() {
    DecisionTree root = new DecisionTree("A riddle appears before you: 'What comes once in a minute, twice in a moment, but never in a thousand years? What is it?'");

    // Correct answer path
    DecisionTree correctAnswer = new DecisionTree("You answered correctly! You receive the Orb of Justice!", "The Orb of Justice is in safe hands. You saved your kingdom. Congratulations, YOU WIN!") {
        @Override
        public void applyStatsChange(Player player) {
            // Any additional effects or rewards can be added here
            player.addExperience(100); // Bonus for solving the riddle
        }
    };

    // Incorrect answer path (Game over, room collapses)
    DecisionTree incorrectAnswer = new DecisionTree("Wrong answer.", "The room starts to collapse.") {
        @Override
        public void applyStatsChange(Player player) {
            // Game ends here, apply a health penalty or end the game
            System.out.println("The room collapses as you fail to answer the riddle correctly!");
            player.reduceHealth(player.getHealth()); // Set health to 0 (player loses)
            System.out.println("GAME OVER...");
        }
    };

    // Add the correct and incorrect choices to the decision tree
    root.addChoice("m", correctAnswer);  // Correct answer is 'time'
    root.addChoice("other", incorrectAnswer);  // Any other answer is incorrect

    return root;
}


private static void traverseDecisionTree(DecisionTree node, Player player, Scanner scanner) {
    while (!node.isLeaf()) {
        System.out.println(node.question);  // Display current decision point's question to the player
        
        // Check if it's a riddle node
        if (node.question.contains("riddle")) {
            System.out.println("You must solve the riddle without choices.");
            createRiddleWithCountdown(player, scanner);

            String answer = scanner.nextLine().toLowerCase();  // Player enters answer

            // Check if the answer is correct
            if (answer.equals("m")) {  // Correct answer for the riddle
                node = node.choices.get("m");  // Move to the correct answer node
                node.canChoose(player);
                node.applyStatsChange(player);
                node.updateInventory(player);
            } else {
                node = node.choices.get("other");  // Move to the incorrect answer node
                node.canChoose(player);
                node.applyStatsChange(player);
                node.updateInventory(player);
                
                // Print once and break the loop
                if (player.getHealth() <= 0) {
                	player.isDead();
                	break;
                }
                return;  // Exit after wrong answer to avoid further repetitions
            }
        } else {
            System.out.println("Choices: " + node.choices.keySet());  // Display available choices to player

            String choice = scanner.nextLine().toLowerCase();

            if (node.choices.containsKey(choice)) {
                node = node.choices.get(choice);  
                node.canChoose(player);
                node.applyStatsChange(player);  
                node.updateInventory(player);  

                // If the game ends, break out of the loop
                if (player.getHealth() <= 0) {
					player.isDead();                    
					break;
                }
            } else {
                System.out.println("Invalid choice. Try again");  // Inform the player if the choice is invalid
            }
        }
    }

    // Print the result after reaching a leaf node (end of decision tree)
    if (player.getHealth() > 0) {
        System.out.println(node.result);  // Display the result if the player is still alive
    }
}




private static void printMap() {
    System.out.println("\n    Follow this path:    ");
    System.out.println("             [Room 3]---->[Room 4]");
    System.out.println("                 |");
    System.out.println(" [Room 1] ----> [Room 2]");
    System.out.println("    |");
    System.out.println("  [You start here]");
    System.out.println("___________________________________________");
}

private static void handleRoomLogic(Room currentRoom, Scanner scanner) {
    if (visitedRooms.contains(currentRoom)) {
        System.out.println("You have already visited this room. There's nothing left to do here.");
        return; //exit the method to prevent redos
    }

    // Mark the room as visited
    visitedRooms.add(currentRoom);

    // Room-specific logic
    if (currentRoom.name.equals("Room 1")) {
        System.out.println("The room is dark. You might hurt yourself walking in there, but the Orb might be here!" +
                " Do you want to walk in? (yes/no)");
        String input = scanner.nextLine();
        if (input.equalsIgnoreCase("yes")) {
            traverseDecisionTree(enterRoom1(), player, scanner);
        } else if (input.equalsIgnoreCase("no")) {
            System.out.println("The doors shut behind you, but a loud voice warns you,'There is no escape without the Orb.' " +
                    "The voice scares you, and you stumble into Room 2.");
        }
    } else if (currentRoom.name.equals("Room 2")) {
        traverseDecisionTree(createItemInteractionTree(), player, scanner);
    } else if (currentRoom.name.equals("Room 3")) {
        System.out.println("A monster appears!");
        traverseDecisionTree(createCombatTree(), player, scanner);
    } else if (currentRoom.name.equals("Room 4")) {
    	System.out.println("Solve this riddle to claim the Orb of Justice!");
//        long startTime = System.currentTimeMillis();
        traverseDecisionTree(createRiddleTree(), player, scanner); // Riddle decision tree
        
//        long elapsedTime = System.currentTimeMillis() - startTime;
//        if (elapsedTime > 30000) {
//            System.out.println("Time's up! The orb remains locked away.");
//        }
//        break; // Game ends after solving the riddle

     }

}


public static void main(String[] args) {

 Room start = new Room("Start", "You are at the labyrinth entrance.");
 Room room1 = new Room("Room 1", "You are in room 1");
 Room room2 = new Room("Room 2", "You are in room 2");
 Room room3 = new Room("Room 3", "You are in room 3");
 Room room4 = new Room("Room 4", "You are in room 4");
 
 start.connectRoom("north", room1);
 room1.connectRoom("south", start);
 room1.connectRoom("east", room2);
 room2.connectRoom("west", room1);
 room2.connectRoom("north", room3);
 room3.connectRoom("south", room2);
 room3.connectRoom("east", room4);
 room4.connectRoom("west", room3);

    //display map
    printMap();     

    //game loop
    Room currentRoom = start;
    Stack<Room> roomHistory = new Stack<>();
    Scanner scanner = new Scanner(System.in);

    System.out.println("Welcome to The Mystery of the Labyrinth!");
    System.out.println("Find the Orb of Justice to save your kingdom!");
    System.out.println();
    System.out.println("Commands: \n" + "Type 'map' to view the map \n" 
    + "Type 'north', 'south', 'east', or 'west' to navigate. \n"
    + "Type 'quit' to exit the game \n"
    + "Type 'stats' to view stats \n"
    + "Type 'inventory' to view inventory \n");
    
    while (true) {
        //display current room and its details
        System.out.println("\n" + currentRoom.name + ": " + currentRoom.description);
        handleRoomLogic(currentRoom, scanner);
        //checking if health is 0 and restart option
        if (player.isDead()) {
            System.out.println("You were defeated by the darkness of the Labyrinth.");
            System.out.print("Would you like to restart? (yes/no): ");
            String restartChoice = scanner.nextLine().toLowerCase();
            if (restartChoice.equals("yes")) {
                //reset the player stats and restart the game
                player = new Player();  
                player.resetStats();
                visitedRooms.clear();  
                currentRoom = start;  
            } else {
                System.out.println("Thanks for playing!");
                System.exit(0);  //exit the game
            }
        }
        // Movement and actions
        System.out.println("Available directions: " + currentRoom.connections.keySet());
        System.out.print("Type a direction, 'inventory', 'stats', 'map, 'undo', or 'quit': ");
        String input = scanner.nextLine().toLowerCase();
        
        if (input.equals("quit")) {
            System.out.println("Thanks for playing!");
            break;
        }else if (input.equals("map")) {
            printMap();
        } else if (input.equals("inventory")) {
            player.viewInventory();
        } else if (input.equals("stats")) {
            System.out.println(player.stats);
        } else if (input.equals("undo")) {
            if (!roomHistory.isEmpty()) {
                currentRoom = roomHistory.pop(); // Go back to the previous room
            }
        } else if (currentRoom.connections.containsKey(input)) {
            roomHistory.push(currentRoom);
            currentRoom = currentRoom.connections.get(input);
        } else {
        	System.out.println("Invalid command. Try 'north', 'south', 'east', 'west', 'inventory', 'stats', 'map, 'undo', or 'quit'.");        }
    }
    
   
    	scanner.close();
	}
}


