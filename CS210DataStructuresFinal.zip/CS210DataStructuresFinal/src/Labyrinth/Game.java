package Labyrinth;

import java.util.*;

public class Game {
	//prevent the player from reentering visited rooms
	static Set<Room> visitedRooms = new HashSet<>();

    //creating player 
    static Player player = new Player();
    

    //thread
    private static void createRiddleWithCountdown(Player player, Scanner scanner) {
        // Riddle setup
        DecisionTree riddleTree = createRiddleTree();
        CountdownThread countdownThread = new CountdownThread(30000); // 30 seconds countdown

        // Start the countdown thread
        countdownThread.start();

        // Prompt player for riddle answer
        System.out.println(riddleTree.question);

        String answer = scanner.nextLine().toLowerCase(); // Player inputs answer
        countdownThread.interrupt(); // Stop the timer as soon as the player answers

        try {
            countdownThread.join(); // Wait for thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Process riddle answer
        if (countdownThread.isTimeExpired()) {
            System.out.println("You failed to solve the riddle in time. You vanish under the rubble and the orb is locked forever!");
        } else if (answer.equals("m")) { //correct answer
            riddleTree = riddleTree.choices.get("m");
            riddleTree.applyStatsChange(player);
            System.out.println(riddleTree.result);
        } else { // Incorrect answer
            riddleTree = riddleTree.choices.get("other");
            riddleTree.applyStatsChange(player);
            System.out.println(riddleTree.result);
        }
    }



    //room1    
    private static DecisionTree enterRoom1() {
        DecisionTree root = new DecisionTree("You step into the room and hear a click. \n" + "A trap is triggered! What will you do?" + "\n" 
        		+ "a. Carefully, escape the trap! Why would I want to hurt myself?! \n" 
        		+ "b. Give in to the pain. I might gain xp from this. Nothing is guaranteed. ");
        
        //avoid path
        DecisionTree escape = new DecisionTree("You disarm the trap and carefully step aside. \n" + "It looks like you gained xp from this!", "You safely avoid the trap!");
        DecisionTree gainXP = new DecisionTree("XP change. Check your stats", "Keep it up! You automatically level up when you reach 10XP.") {
	        @Override
	        public void applyStatsChange(Player player) {
	            player.addExperience(3); 
	        }
        };
        escape.addChoice("View XP", gainXP);
        
        //painful path
        DecisionTree trigger = new DecisionTree("Remember, you signed up for this...", "Your health deacreases by 50HP.");
        trigger.addChoice("ok", new DecisionTree("You lose a lot of blood.", "Unfortunately, the trap does not give you xp. Your sacrifice was useless.") {
         @Override
         public void applyStatsChange(Player player) {
             player.reduceHealth(50); //the player takes 50 damage for thinking trap will give xp
	         	}
	        }); 
               
		 root.addChoice("a", escape);
		 root.addChoice("b", trigger);
		 
		 return root;
		}
//room 2
private static DecisionTree createItemInteractionTree() {
			 //root
		 DecisionTree root = new DecisionTree("You find a Healing Potion and a Sword in this room. What will you do? \n" + "Choices: \n" + 
					 "a. Pick up sword and healing potion. I'll use them later \n" 
					 + "b. Leave, these items will slow me down \n" 
					 + "c. Leave the sword, but use the potion right now. I might not get the chance later");
		 
		 //player picks up the healing potion and sword
		 DecisionTree pickItems = new DecisionTree("You pick up the Healing Potion and Sword.", 
		         "You now have a Healing Potion and Sword. They will be useful in Room 3 when facing the monster!");
		 pickItems.addChoice("ok", new DecisionTree("Items added to inventory.", "The Sword fits firmly in your grip," 
		         + "and the Potion's presence offers hope. The real test lies ahead..." + "Use them wisely on your journey.") {
	         @Override
	         public void updateInventory(Player player) {
			        if (!player.hasItem("Sword")) {
			            player.addItem("Sword");
			        }
			        if (!player.hasItem("Healing Potion")) {
			            player.addItem("Healing Potion");
			        }
		            if (player.getHealth() < 70) {
		                player.reduceHealth(10);
		                System.out.println("You are already injured. Your wounds worsen as you carry these items.");
		            }
	         }
		 }); 
		
		 //player chooses to leave the items behind
		 DecisionTree leaveItems = new DecisionTree("You decide not to pick up the items because you are lazy.", 
		         "You leave the Healing Potion and Sword behind. You might regret this decision later...");
		
		 //player takes potion
		 DecisionTree heal = new DecisionTree("Do you feel renewed?", "Your wounds close, and a wave of energy flows through you, revitalizing your spirit.") {
			    @Override
			    public void updateInventory(Player player) {
			        if (!player.hasItem("Healing Potion")) {
			            player.addItem("Healing Potion");
			        }
			        player.removeItem("Healing Potion");
			    }
		        @Override
		        public void applyStatsChange(Player player) {
		            player.increaseHealth(100); //max out health
		        }
			};
		
		 root.addChoice("a", pickItems);
		 root.addChoice("b", leaveItems);
		 root.addChoice("c", heal);
		
		 return root;
		}


//room 3
private static DecisionTree createCombatTree() {
    DecisionTree root = new DecisionTree(
            "Your footsteps wake the Goblin up. He gets up angrily! What will you do? \n" +
            "Choices: \n" +
            "a. Attack! I'll swing at him with my fists.\n" +
            "b. Flee! I have no chance against him.\n" +
            "c. Use the sword! I can finish him. ") {

    };
    DecisionTree sword = new DecisionTree("You use the sword to attack.", "You won the fight! The goblin disappears.") {
    	@Override
    	public boolean canChoose(Player player) {
    		 if (player.hasItem("Healing Potion")) {
                 System.out.println("The Goblin startles you, so you spill your healing potion!");
                 player.removeItem("Healing Potion");
             }
    	    if (!player.hasItem("Sword")) {
    	        System.out.println("You reach for the sword, but you notice you don't have it! \n" + ""
    	        		+ "The Goblin takes advantage of your hesitation and attacks you first. \n" 
    	        		+ "All you have is your fists!");
    	        player.reduceHealth(20); //penalty for not remembering
                player.addExperience(6); //goblin defeat reward

    	        return false;
    	    }else {   
                player.addExperience(10); //goblin defeat reward
                System.out.println("You slayed the Goblin!");
    	    	return true;}
    	}

        @Override
        public void updateInventory(Player player) {
            player.removeItem("Sword");
        }

        @Override
        public void applyStatsChange(Player player) {
        	//stats updated based on if player canchoose() the sword            
        }
    };
    // Attack path (using fists)
    DecisionTree attack = new DecisionTree("You attack the monster.", "You dealt damage, but the monster fled!") {
        @Override
        public void applyStatsChange(Player player) {
            player.reduceHealth(10); 
            player.addExperience(5); // Reward for using fists
        }
    	@Override
    	public boolean canChoose(Player player) {
    		 if (player.hasItem("Healing Potion")) {
                 System.out.println("The Goblin startles you, so you spill your healing potion!");
                 player.removeItem("Healing Potion");
             }
			return true;
    	}

    };

    // Flee path
    DecisionTree flee = new DecisionTree("You try to flee, but the Goblin catches up!", "As you flee, the Goblin harmed you.") {
    	@Override
    	public boolean canChoose(Player player) {
    		 if (player.hasItem("Healing Potion")) {
                 System.out.println("The Goblin startles you, so you spill your healing potion!");
                 player.removeItem("Healing Potion");
             }
			return true;
    	}
        @Override
        public void applyStatsChange(Player player) {
            player.reduceHealth(20); // Fleeing could cause a penalty for failing to escape
            player.addExperience(2); // Small reward for fleeing

        }
        
    };

    // Link decisions
    root.addChoice("a", attack);
    root.addChoice("b", flee);
    root.addChoice("c", sword);


    return root;
}




//room 4
private static DecisionTree createRiddleTree() {
    DecisionTree root = new DecisionTree("You see the orb locked in a treasure chest. As you approach it, a riddle appears before you: \n" + 
    		"\n 'What comes once in a minute, twice in a moment, but never in a thousand years? What is it?' \n"
    		+"Hurry! You have 30 seconds to solve the riddle and claim the Orb of Justice.");

    // Correct answer path
    DecisionTree correctAnswer = new DecisionTree("You answered correctly! You receive the Orb of Justice!", "The Orb of Justice is in safe hands. You saved your kingdom. Congratulations, YOU WIN!") {
        @Override
        public void applyStatsChange(Player player) {
            // Any additional effects or rewards can be added here
            player.addExperience(100); // Bonus for solving the riddle
        }
    };

    // Incorrect answer path (Game over, room collapses)
    DecisionTree incorrectAnswer = new DecisionTree("Wrong answer.", "GAME OVER.") {
        @Override
        public void applyStatsChange(Player player) {
            // Game ends here, apply a health penalty or end the game
            System.out.println("The room collapses as you fail to answer the riddle correctly!");
            player.reduceHealth(player.getHealth()); // Set health to 0 (player loses)
        }
    };

    // Add the correct and incorrect choices to the decision tree
    root.addChoice("m", correctAnswer);  // Correct answer is 'time'
    root.addChoice("other", incorrectAnswer);  // Any other answer is incorrect

    return root;
}

private static void traverseDecisionTree(DecisionTree node, Player player, Scanner scanner) {
    while (!node.isLeaf()) {
        // If the current node is a riddle, skip printing the question in the regular way
        if (node.question.contains("riddle")) {
            createRiddleWithCountdown(player, scanner);
//            System.out.println("You must solve the riddle without choices.");

            String answer = scanner.nextLine().toLowerCase(); 

            if (answer.equals("m")) {  
                node = node.choices.get("m");  
                node.canChoose(player);
                node.applyStatsChange(player);
                node.updateInventory(player);
            } else {
                node = node.choices.get("other");  
                node.canChoose(player);
                node.applyStatsChange(player);
                node.updateInventory(player);
                
                // Print once and break the loop
                if (player.getHealth() <= 0) {
                    player.isDead();
                    break;
                }
                return;  
            }
        } else {
            System.out.println(node.question);  //display question for other decision nodes
            System.out.println("Choices: " + node.choices.keySet());  //display choices to player

            String choice = scanner.nextLine().toLowerCase();

            if (node.choices.containsKey(choice)) {
                node = node.choices.get(choice);  
                node.canChoose(player);
                node.applyStatsChange(player);  
                node.updateInventory(player);  

                //if the game ends, break out of the loop
                if (player.getHealth() <= 0) {
                    player.isDead();                    
                    break;
                }
            } else {
                System.out.println("Invalid choice. Try again");  
            }
        }
    }

    //display the result after reaching a leaf node if player alive
    if (player.getHealth() > 0) {
        System.out.println(node.result);  
    }
}


private static void printMap() {
    System.out.println("\n__________________ MAP__________________ \n ");
    System.out.println("             [Room 3]---->[Room 4]");
    System.out.println("                 |");
    System.out.println(" [Room 1] ----> [Room 2]");
    System.out.println("    |");
    System.out.println("[Entrance]");
    System.out.println("___________________________________________");
}

private static void handleRoomLogic(Room currentRoom, Scanner scanner) {
    if (visitedRooms.contains(currentRoom)) {
        System.out.println("You have already visited this room. There's nothing left to do here.");
        return; //exit the method to prevent replay
    }

    //mark as visited
    visitedRooms.add(currentRoom);

    //Room-specific general game logic
    if (currentRoom.name.equals("Room 1")) {
        System.out.println("The room is dark. You might hurt yourself walking in there, but the Orb might be here!" +
                " Do you want to walk in? (yes/no)");
        String input = scanner.nextLine();
        if (input.equalsIgnoreCase("yes")) {
            traverseDecisionTree(enterRoom1(), player, scanner);
        } else if (input.equalsIgnoreCase("no")) {
            System.out.println("The doors shut behind you, but a loud voice warns you,'There is no escape without the Orb.' " +
                    "The voice scares you, and you stumble into Room 2.");
        }
    } else if (currentRoom.name.equals("Room 2")) {
        traverseDecisionTree(createItemInteractionTree(), player, scanner);
    } else if (currentRoom.name.equals("Room 3")) {
        System.out.println("A monster appears!");
        traverseDecisionTree(createCombatTree(), player, scanner);
    } else if (currentRoom.name.equals("Room 4")) {
    	System.out.println("The walls of the room begin to shake. \n ");
        traverseDecisionTree(createRiddleTree(), player, scanner); //riddle decision tree      
     }

}


public static void main(String[] args) {

 Room start = new Room("Start", "You are at the labyrinth entrance.");
 Room room1 = new Room("Room 1", "You are in room 1");
 Room room2 = new Room("Room 2", "You are in room 2");
 Room room3 = new Room("Room 3", "You are in room 3");
 Room room4 = new Room("Room 4", "You are in room 4");
 
 start.connectRoom("north", room1);
 room1.connectRoom("south", start);
 room1.connectRoom("east", room2);
 room2.connectRoom("west", room1);
 room2.connectRoom("north", room3);
 room3.connectRoom("south", room2);
 room3.connectRoom("east", room4);
 room4.connectRoom("west", room3);
 

    //game loop
    Room currentRoom = start;
    Stack<Room> roomHistory = new Stack<>();
    Scanner scanner = new Scanner(System.in);

    System.out.println("Welcome to The Mystery of the Labyrinth!");
    System.out.println("You live in a kingdom ruled by a corrupt king and evil shadows. As you take your usual evening stroll in the hills by your cottage, you trip and tumble upon a hidden cave.");
    System.out.println("You stumble into the cave, landing with a painful thud. The air is thick with mystery, and your body aches from the fall.");
    System.out.println("Knowing that the entire village has been looking for the legendary Orb of Justice, you realize this mysterious and dangerous \n"
    		+ "underground maze filled with magic, traps, and monsters could be holding the key to defeating evil.");
    System.out.println("Your goal is to retrieve the legendary Orb of Justice that is rumored to grant unlimited power to its wielder.");
    System.out.println("However, the crypt is alive with magic, and your every decision will determine your fate.");
    System.out.println();
    System.out.println("As the pain from the tumble subsides, your health is not at its peak, but you are still alive and determined.");
    System.out.println("You start with 70 health due to the injuries sustained from the fall. Watch out for the dangers lurking ahead.");
    System.out.println("Prepare yourself; the labyrinth awaits!");

    System.out.println("\nCurrent Stats:");
    System.out.println(player.stats);

    printMap();    

    System.out.println("Find the Orb of Justice to save your kingdom!");
    System.out.println();
    System.out.println("Commands: \n" + "Type 'map' to view the map \n" 
    + "Type 'north', 'south', 'east', or 'west' to navigate. \n"
    + "Type 'quit' to exit the game \n"
    + "Type 'stats' to view stats \n"
    + "Type 'inventory' to view inventory \n");
    
    while (true) {
        //display current room and its details
        System.out.println("\n" + currentRoom.name + ": " + currentRoom.description);
        handleRoomLogic(currentRoom, scanner);
        //checking if health is 0 and restart option
        if (player.isDead()) {
            System.out.println("You were defeated by the darkness of the Labyrinth.");
            System.out.print("Would you like to restart? (yes/no): ");
            String restartChoice = scanner.nextLine().toLowerCase();
            if (restartChoice.equals("yes")) {
                //reset the player stats and restart the game
                player = new Player();  
                player.resetStats();
                visitedRooms.clear();  
                currentRoom = start;  
            } else {
                System.out.println("Thanks for playing!");
                System.exit(0);  //exit the game
            }
        }
        //movement and actions
        System.out.println("Available directions: " + currentRoom.connections.keySet());
        System.out.print("Type a direction, 'inventory', 'stats', 'map, 'undo', or 'quit': ");
        String input = scanner.nextLine().toLowerCase();
        
        if (input.equals("quit")) {
            System.out.println("Thanks for playing!");
            break;
        }else if (input.equals("map")) {
            printMap();
        } else if (input.equals("inventory")) {
            player.viewInventory();
        } else if (input.equals("stats")) {
            System.out.println(player.stats);
        } else if (input.equals("undo")) {
            if (!roomHistory.isEmpty()) {
                currentRoom = roomHistory.pop(); //go back to the previous room
            }
        } else if (currentRoom.connections.containsKey(input)) {
            roomHistory.push(currentRoom);
            currentRoom = currentRoom.connections.get(input);
        } else {
        	System.out.println("Invalid command. Try 'north', 'south', 'east', 'west', 'inventory', 'stats', 'map, 'undo', or 'quit'.");        }
    }
    
   
    	scanner.close();
	}
}


