package Labyrinth;

public class CountdownThread extends Thread {
    private final long timeLimit;
    private volatile boolean timeExpired;

    public CountdownThread(long timeLimit) {
        this.timeLimit = timeLimit;
        this.timeExpired = false;
    }

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        long elapsedTime = 0;

        while (elapsedTime < timeLimit && !isInterrupted()) {
            try {
                long remainingTime = (timeLimit - elapsedTime) / 1000; // Convert to seconds
                System.out.print("\rTime left: " + remainingTime + " seconds ");
                Thread.sleep(100); // Wait for 0.1 seconds
                elapsedTime = System.currentTimeMillis() - startTime;
            } catch (InterruptedException e) {
                // Exit loop if interrupted
                break;
            }
        }

        if (elapsedTime >= timeLimit) {
            timeExpired = true; // Mark time as expired
        }
    }

    public boolean isTimeExpired() {
        return timeExpired;
    }
}
