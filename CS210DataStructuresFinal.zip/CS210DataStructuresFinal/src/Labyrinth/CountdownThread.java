package Labyrinth;

public class CountdownThread extends Thread {
    private final long timeLimit;
    private volatile boolean timeExpired;

    public CountdownThread(long timeLimit) {
        this.timeLimit = timeLimit;
        this.timeExpired = false;
    }

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        long elapsedTime = 0;

        while (elapsedTime < timeLimit && !isInterrupted()) {
            try {
                // Calculate the remaining time in seconds
                long remainingTime = (timeLimit - elapsedTime) / 1000; 
                System.out.print("\rTime left: " + remainingTime + " seconds ");
                Thread.sleep(1000); // Sleep for 1 second before updating the time

                // Update elapsed time after 1 second has passed
                elapsedTime = System.currentTimeMillis() - startTime;
            } catch (InterruptedException e) {
                // Exit loop if interrupted
                break;
            }
        }

        if (elapsedTime >= timeLimit) {
            timeExpired = true; // Mark time as expired
        }
    }

    public boolean isTimeExpired() {
        return timeExpired;
    }
}
