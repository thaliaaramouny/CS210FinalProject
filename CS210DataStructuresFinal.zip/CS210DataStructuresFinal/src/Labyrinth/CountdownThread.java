package Labyrinth;

public class CountdownThread extends Thread {
    private long timeLimit;
    private volatile boolean timeExpired;

    public CountdownThread(long timeLimit) {
        this.timeLimit = timeLimit;
        this.timeExpired = false;
    }

    public boolean isTimeExpired() {
        return timeExpired;
    }

    @Override
    public void run() {
        try {
            for (long remaining = timeLimit; remaining > 0; remaining -= 1000) {
                if (isInterrupted()) {
                    System.out.println("Timer interrupted!");
                    break;  //stop countdown if interrupted
                }
                if (timeExpired) break; //stop countdown if time is expired
                System.out.println("Time left: " + remaining / 1000 + " seconds.");
                Thread.sleep(1000); //update countdown every second
            }
            timeExpired = true; //mark time as expired after countdown done
            if (!timeExpired) {
                System.out.println("Time is up!");
            }
        } catch (InterruptedException e) {
            System.out.println("Timer stopped.");
        }
    }
}
