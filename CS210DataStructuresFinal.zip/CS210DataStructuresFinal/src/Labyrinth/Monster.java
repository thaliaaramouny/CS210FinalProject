package Labyrinth;


public class Monster {
    String name;
    int health;
    int attack;

    public Monster(String name, int health, int attack) {
        this.name = name;
        this.health = health;
        this.attack = attack;
    }

    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            System.out.println(name + " has been defeated!");
        } else {
            System.out.println(name + " has " + health + " health left.");
        }
    }

    public boolean isDefeated() {
        return health <= 0;
    }

}


