package Labyrinth;

public class Monster {
    private String name;
    private int health;
    private int attackDamage;

    public Monster(String name, int health, int attackDamage) {
        this.name = name;
        this.health = health;
        this.attackDamage = attackDamage;
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public int getAttackDamage() {
        return attackDamage;
    }

    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            health = 0;
            System.out.println(name + " has been defeated!");
        } else {
            System.out.println(name + " has " + health + " health left.");
        }
    }

    public boolean isDefeated() {
        return health <= 0;
    }

    public void attackPlayer(Player player) {
        System.out.println(name + " attacks! Dealing " + attackDamage + " damage.");
        player.reduceHealth(attackDamage);
    }
}
