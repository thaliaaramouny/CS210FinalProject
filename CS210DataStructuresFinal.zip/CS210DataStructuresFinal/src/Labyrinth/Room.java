package Labyrinth;

import java.util.*;

public class Room {
    String name;
    String description;
    Map<String, Room> connections; //adjacency list
    Monster monster;
    DecisionTree decisionTree; //adding decision tree to room

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
        this.connections = new HashMap<>();
    }

    public void connectRoom(String direction, Room room) {
        connections.put(direction.toLowerCase(), room);
    }

    public Room getConnectedRoom(String direction) {
        return this.connections.get(direction);
    }
    
    public boolean hasMonster() {
        return monster != null;
    }

    public void setMonster(Monster monster) {
        this.monster = monster;
    }

    public void setDecisionTree(DecisionTree tree) {
        this.decisionTree = tree;
    }

    public boolean hasDecisionTree() {
        return decisionTree != null;
    }


 
    
}
